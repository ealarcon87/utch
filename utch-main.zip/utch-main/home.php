<!DOCTYPE html>
<html>
<head>
    <title>Bienvenido</title>
</head>
<body>

<h1>Bienvenido a la aplicación del Equipo 2</h1>
<p>Login correcto. ¡Ya puedes entregar la práctica!</p>

<a href="index.php">Cerrar sesión</a>

</body>
</html>
