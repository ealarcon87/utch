<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Bienvenido</title>
<style>
    body {
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background: linear-gradient(135deg, #00b4d8, #0077b6);
        font-family: Poppins, sans-serif;
        color: white;
    }

    .box {
        background: rgba(255,255,255,0.15);
        padding: 40px;
        border-radius: 15px;
        backdrop-filter: blur(10px);
        text-align: center;
    }

    h1 {
        margin-bottom: 10px;
        font-size: 32px;
    }
</style>
</head>

<body>
<div class="box">
    <h1>Bienvenido, Saul 🎉</h1>
    <p>Has iniciado sesión correctamente.</p>
</div>
</body>
</html>
