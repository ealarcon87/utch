<?php
// Lógica del login sin base de datos
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $pass  = $_POST['password'];

    // Usuario fijo
    $validUser = "saul";
    $validPass = "1234";

    if ($email === $validUser && $pass === $validPass) {
        header("Location: home.php");
        exit;
    } else {
        $error = "Usuario o contraseña incorrectos.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Login Ultra Bonito</title>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }

    body {
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #0d1b2a, #1b263b, #415a77);
        background-size: 300% 300%;
        animation: gradientBG 10s ease infinite;
        color: white;
    }

    @keyframes gradientBG {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }

    .login-container {
        background: rgba(255, 255, 255, 0.08);
        backdrop-filter: blur(12px);
        padding: 40px;
        border-radius: 18px;
        width: 350px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.5);
        border: 1px solid rgba(255,255,255,0.2);
        animation: fadeIn 0.6s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to   { opacity: 1; transform: translateY(0); }
    }

    h2 {
        text-align: center;
        margin-bottom: 25px;
        font-size: 28px;
        letter-spacing: 1px;
    }

    .input-group {
        margin-bottom: 18px;
    }

    .input-group label {
        font-size: 14px;
        opacity: 0.9;
    }

    .input-group input {
        width: 100%;
        padding: 12px;
        margin-top: 5px;
        border: none;
        border-radius: 10px;
        outline: none;
        background: rgba(255,255,255,0.15);
        color: white;
        font-size: 15px;
        transition: 0.2s;
    }

    .input-group input:focus {
        background: rgba(255,255,255,0.25);
        box-shadow: 0 0 0 2px #4cc9f0;
    }

    .btn {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 10px;
        background: #4cc9f0;
        color: #0d1b2a;
        font-weight: bold;
        font-size: 16px;
        cursor: pointer;
        margin-top: 10px;
        transition: 0.2s;
    }

    .btn:hover {
        background: #72efdd;
    }

    .error {
        background: rgba(255, 0, 0, 0.2);
        padding: 10px;
        border-left: 4px solid #ff6b6b;
        color: #ffaaaa;
        margin-bottom: 15px;
        border-radius: 6px;
        font-size: 14px;
    }

</style>

</head>
<body>

<div class="login-container">
    <h2>Iniciar Sesión</h2>

    <?php if (!empty($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        
        <div class="input-group">
            <label>Usuario:</label>
            <input type="text" name="email" required placeholder="Ingresa tu usuario">
        </div>

        <div class="input-group">
            <label>Contraseña:</label>
            <input type="password" name="password" required placeholder="********">
        </div>

        <button class="btn" type="submit">Entrar</button>
    </form>
</div>

</body>
</html>
